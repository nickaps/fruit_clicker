
// The sad little autoclick method that lives alone here
function autoClick() {
    score += level;
    updateUI();
    checkScore();
}
